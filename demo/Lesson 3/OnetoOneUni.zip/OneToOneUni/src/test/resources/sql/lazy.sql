-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: eacore
-- ------------------------------------------------------
-- Server version	5.6.26-log

 
 
INSERT INTO `credentials` VALUES ('JohnDoe',NULL,'DoeNuts',NULL);
  

--
-- Table structure for table `member`
--
 
--
-- Dumping data for table `member`
--

 
 
INSERT INTO `member` VALUES (1,0,'Sean','Smith',1,NULL,'JohnDoe');
 
  
-- Dump completed on 2017-04-10 22:09:29
