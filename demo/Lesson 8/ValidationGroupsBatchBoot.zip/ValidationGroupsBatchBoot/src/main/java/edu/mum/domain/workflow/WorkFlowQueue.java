package edu.mum.domain.workflow;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import edu.mum.domain.Member;

@Entity
@Table(name="workflowqueue")
public class WorkFlowQueue {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	@OneToOne(fetch= FetchType.EAGER)
	Member member;


/*
	 * @ElementCollection
	 * Defines a collection of instances of a basic type or embeddableclass. 
	 * Must be specified if the collection is to be mapped by means of a collection table.
	 */
	   @ElementCollection(fetch= FetchType.EAGER)
	    private Set<Long> productQueue = new HashSet<Long>();
	    
	   @ElementCollection(fetch= FetchType.EAGER)
	    private Set<Long> memberQueue = new HashSet<Long>();
	    
	public WorkFlowQueue() {
		
	}
	public WorkFlowQueue(Member member) {
		this.member = member;
	}

    
	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}

	public Member getMember() {
		return member;
	}

	public void setMember(Member member) {
		this.member = member;
	}
	
	public   Set<Long> getProductQueue() {
		return   productQueue;
	}
	
	public void setProductQueue(Set<Long> productQueue) {
		this.productQueue = productQueue;
	}

	public   Set<Long> getMemberQueue() {
		return   memberQueue;
	}
	
	public void setMemberQueue(Set<Long> memberQueue) {
		this.memberQueue = memberQueue;
	}
	
	@SuppressWarnings("null")
	public   Set<Long> getQueue(WorkFlowType workFlowType) {
		
		Set<Long> queue = null;
		
		switch (workFlowType) {
		
			case PRODUCT:
				queue = this.productQueue;
				break;
				
			case MEMBER:
				queue = this.memberQueue;
		}
		
		return   queue;
	}


}
