package edu.mum;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.context.annotation.PropertySource;


 
@Configuration
@Profile("prod")
@PropertySource(value="classpath:application-prod.properties")
public class AmqpProdConfiguration {

/*    <rabbit:connection-factory id="connectionFactory" host="localhost" username="joe" password="joe"/>*/  
		// Connecting to Cloud  RabbitMQ Broker
	/*
	 * @Bean public ConnectionFactory connectionFactory() { CachingConnectionFactory
	 * connectionFactory = new CachingConnectionFactory("localhost");
	 * connectionFactory.setUri(
	 * "amqp://nyngjurd:A1qlg5R5-7rdIQsRXoHRF3s49M58VOfD@skunk.rmq.cloudamqp.com/nyngjurd"
	 * ); return connectionFactory; }
	 * 
	 * 
	 */	    
/*
	   <!--  ****************  Store CONSUMER ************************* -->
	    <rabbit:listener-container connection-factory="connectionFactory">
	   	<rabbit:listener ref="queueListener" method="listen" queue-names="orderStoreQueue" />
	   </rabbit:listener-container>

	   <bean id="queueListener" class="edu.mum.amqp.DirectStoreListener" />

*/		   

		   
	/*
	 * @Bean public SimpleMessageListenerContainer directListenerContainer() {
	 * SimpleMessageListenerContainer container = new
	 * SimpleMessageListenerContainer();
	 * container.setConnectionFactory(connectionFactory());
	 * container.setQueueNames("orderStoreQueue"); container.setMessageListener(new
	 * MessageListenerAdapter(queueListener(),"listen")); return container; }
	 * 
	 * @Bean DirectStoreListener queueListener() { return new DirectStoreListener();
	 * }
	 * 
	 */ 
}
