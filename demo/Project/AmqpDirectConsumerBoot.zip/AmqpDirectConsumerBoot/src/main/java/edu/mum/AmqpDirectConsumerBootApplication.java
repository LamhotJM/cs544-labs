package edu.mum;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class AmqpDirectConsumerBootApplication implements CommandLineRunner {
	
	@Autowired
	private ApplicationContext context;
	
	public static void main(String[] args) {
		SpringApplication.run(AmqpDirectConsumerBootApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
	
	       BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
	        System.out.println();
	        
			System.out.println("---------- Messages read from OrderStoreQueue on Order Direct Exchange ");

		/*
		 * try { in.readLine(); } catch (IOException e1) { // TODO Auto-generated catch
		 * block e1.printStackTrace(); }
		 * 
		 */
	}

}
