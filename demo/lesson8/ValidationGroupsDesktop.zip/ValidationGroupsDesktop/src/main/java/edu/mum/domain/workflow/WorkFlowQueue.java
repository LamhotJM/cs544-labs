package edu.mum.domain.workflow;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import edu.mum.domain.Member;

@Entity
public class WorkFlowQueue {

	@Id
	private Long id;
	
	@OneToOne(fetch= FetchType.EAGER)
	Member member;


/*
	 * @ElementCollection
	 * Defines a collection of instances of a basic type or embeddableclass. 
	 * Must be specified if the collection is to be mapped by means of a collection table.
	 */
	   @ElementCollection(fetch= FetchType.EAGER)
	    private List<Long> productQueue = new ArrayList<Long>();
	    
	   @ElementCollection(fetch= FetchType.EAGER)
	    private List<Long> memberQueue = new ArrayList<Long>();
	    
	public WorkFlowQueue() {
		
	}
	public WorkFlowQueue(Member member) {
		this.member = member;
	}

    
	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}

	public Member getMember() {
		return member;
	}

	public void setMember(Member member) {
		this.member = member;
	}
	
	public   List<Long> getProductQueue() {
		return   productQueue;
	}
	
	public void setProductQueue(List<Long> productQueue) {
		this.productQueue = productQueue;
	}

	public   List<Long> getMemberQueue() {
		return   memberQueue;
	}
	
	public void setMemberQueue(List<Long> memberQueue) {
		this.memberQueue = memberQueue;
	}
	
	public   List<Long> getQueue(WorkFlowType workFlowType) {
		
		List<Long> queue = null;
		
		switch (workFlowType) {
		
			case PRODUCT:
				queue = this.productQueue;
				break;
				
			case MEMBER:
				queue = this.memberQueue;
		}
		
		return   queue;
	}


}
