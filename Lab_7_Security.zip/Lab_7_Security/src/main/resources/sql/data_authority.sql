 
 INSERT INTO `authority` VALUES (1,'ROLE_ADMIN','Sean'), (4,'ROLE_SUPERVISOR','Paul');


