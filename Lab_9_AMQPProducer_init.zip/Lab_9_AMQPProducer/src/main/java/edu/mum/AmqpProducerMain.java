package edu.mum;

public class AmqpProducerMain {
	
    public static void main(String[] args) {
  
 
    }
}
