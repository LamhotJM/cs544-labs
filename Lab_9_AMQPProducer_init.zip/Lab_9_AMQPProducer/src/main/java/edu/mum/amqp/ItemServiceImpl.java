package edu.mum.amqp;

public class ItemServiceImpl implements ItemService {


}
