package edu.mum.amqp;

public interface ItemService {
 

}
