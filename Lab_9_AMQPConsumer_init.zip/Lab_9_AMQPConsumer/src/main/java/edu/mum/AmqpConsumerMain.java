package edu.mum;

public class AmqpConsumerMain {
	
    public static void main(String[] args) {


    }
}
